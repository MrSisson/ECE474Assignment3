﻿/* Author: Alexander Barber
 * NetID: abarber
 * Assigment: 2
 * Date: November 1 2018
 * Description: Defines the functions and classes for dpgen.cpp
 */
#ifndef HLSYN_H
#define HLSYN_H

#pragma once

#include <iostream>
#include <vector>

using namespace std;

class var {
public:
	string name;
	string width;
	int type; // input: 0, output: 1, wire: 2, register 3.
	bool sign;
	int line;

};

class operation {
public:
	string output;
	string in1;
	string in2; // possible second output.
	string sel; // possible selection var for the MUX.
	string width;
	int type; // the opperation codes, '=': 0, '+': 1, '-': 2, '*': 3, '<': 4, '>': 5, '==': 6, '?': 7, '>>': 8, '<<': 9
	int line;
	bool sign;
	bool error;
	bool used;
};

// Class to contain info for each if statement.
class statement {
public:
	// If-statement conditions.
	string condition;		// The Condition for our if statement.

	// For-loop conditions.
	string itVar;			// The Variable we itterate over.
	string forCond;			// The Condition for our for-loop.
	string incState;		// The Increment statement for our variable.

	// What it contains.
	vector <operation> ops;	// Operations.

	int start;				// Starting brace.
	int end;				// Ending brace.
	int link;				// If statement is else, this points to it's if.
	bool type;				// true is if-state, false is for-loop.

	// If we've found it's closing brace yet.
	bool closed;
};

//
class node {
public:
	/// If the node is a statement.
	bool statementType;			// true is if-state, false is for-loop.

	// If statement condition.
	string condition;			// The Condition for our if statement.

	// For-loop conditions.
	string itVar;				// The Variable we itterate over.
	string forCond;				// The Condition for our for-loop.
	string incState;			// The Increment statement for our variable.

	int start;					// Starting brace.
	int end;					// Ending brace.
	int link;					// Index of starting if statement for the else, for if-statements -1 is linked with an else & -2 is solo.
	
	vector <node> innerNodes;	// Holds any inner nodes.

	/// If the node is an operation.
	operation op;				// Holds operation if it is one.

	/// For List-R scheduling.
	int t_ALAP;					// Time for ALAP scheduling, used to calc slack.
	int slack;					// Slack, used for finding timing.

	/// Node general.
	int type;					// The type of node: 0 operation, 1 if-statement, 2 else-statement, 3 for-loop.

};

// Reads the input file and sets up some vectors for writting.
void readFile(char * in, char* latency, char * out);

// Writes the data saved in the variables and operations vectors to the output file. 
void writeFile(char* out, char* latency, vector <var> &variables, vector <operation> &operations, vector <statement> &statements, int endline);


#endif