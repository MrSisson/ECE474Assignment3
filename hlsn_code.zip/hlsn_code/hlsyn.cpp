﻿/* Author: Alexander Barber
 * NetID: abarber
 * Assigment: 2
 * Date: November 1 2018
 * Description: Reads an input file and converts the netlist text into verilog programming.
 */



#include "hlsyn.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <string>
#include <sstream>
#include <vector>
#include <stdlib.h>
#include <cstdlib>
#include <bitset>

using namespace std;

// writes the parsed string to the output file
void readFile(char * in, char * latency, char * out) {
	// Files.
	fstream netList;

	// Temporary variables for parsing the string.
	string str;
	int count = 1;
	int numVar = 0;
	var tempVar;
	operation tempOp;
	statement tempState;
	string tempName;

	// For statements.
	int numOpenState = 0;	// Number of open states.
	int lowestState = 0;	// Index for the lowest statement in the vector.

	// For general Conditionals.
	bool cond = false;		// Flag for lowest conditional (true is if-statement and false is for-loop).
	
	// Temporaray variables for finding the right way to parse.
	string firstObj;	// Used to find input, output, wire, register, or output variable.
	string secondObj;	// Used to find Int or UInt, also removes the equality symbol.
	string thirdObj;	// Used to find the first or only input.
	string fourthObj;	// Used to find operation errors.

	// Save important info in vectors for the write function.
	vector <var> variables;
	vector <operation> operations;
	vector <statement> statements;

	string width;

	// Delimiters for splitting the strings.
	string space = " ";
	string comma = ",";
	string endLine = "\n";

	size_t pos = 0; // Temp Varaible for finding characters.
	size_t pos2 = 0; // For Fixing comment errors.
	size_t getComment = string::npos; // For finding comments.

	netList.open(in);

	while (!netList.eof()) {
		getline(netList, str);

		getComment = str.find("//");

		// parse the first two lines
		// First
		pos = str.find(space);
		firstObj = str.substr(0, pos);
		str.erase(0, pos + space.length());
		// Second
		pos = str.find(space);
		secondObj = str.substr(0, pos);
		str.erase(0, pos + space.length());

		// Initialize tempState because we need default values for the if/else definintion to work.
		tempState.link = 0; // otherwise any if after an else will always be linked to the same if that else was linked to. May add 'else if (*) {' functionality later if i have time, probably wont though.

		// Check for input signed.
		if (firstObj.compare("input") == 0 && secondObj.substr(0,3).compare("Int") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 3); // pop off the Int.
			width = secondObj;

			pos = str.find(comma);

			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 0;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());
				
				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 0;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Check for output signed.
		else if(firstObj.compare("output") == 0 && secondObj.substr(0, 3).compare("Int") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 3); // pop off the Int.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 1;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());

				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 1;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Check for wire signed.
		else if (firstObj.compare("wire") == 0 && secondObj.substr(0, 3).compare("Int") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 3); // pop off the Int.
			width = secondObj;

			pos = str.find(comma);

			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 2;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());
				
				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);
				
				pos = str.find("\t");
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());

			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 2;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Check for register variable signed.
		else if (firstObj.compare("register") == 0 && secondObj.substr(0, 3).compare("Int") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 3); // pop off the Int.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 3;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());

				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}
				
				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 3;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = true;
				tempVar.name = tempName;
				
				variables.push_back(tempVar);
			}

		}
		// Check for input unsigned.
		else if (firstObj.compare("input") == 0 && secondObj.substr(0, 4).compare("UInt") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 4); // pop off the UInt.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 0;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());

				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 0;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Check for output unsigned.
		else if (firstObj.compare("output") == 0 && secondObj.substr(0, 4).compare("UInt") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 4); // pop off the UInt.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 1;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());

				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 1;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}
		}
		// Check for wire unsigned.
		else if (firstObj.compare("wire") == 0 && secondObj.substr(0, 4).compare("UInt") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 4); // pop off the UInt.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 2;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());
				
				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}
			
			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 2;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Check for register variable unsigned.
		else if (firstObj.compare("register") == 0 && secondObj.substr(0, 4).compare("UInt") == 0) {
			// Find the fixed width of all input values, then remove all but the names of the input variables.
			secondObj.erase(0, 4); // pop off the UInt.
			width = secondObj;

			pos = str.find(comma);
			while (pos != string::npos) { // Itterate over the string.
				// Set what we already know
				tempVar.type = 3;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;

				// Section off the variable names by space.
				tempVar.name = str.substr(0, pos);
				str.erase(0, pos + space.length() + comma.length());

				if (tempVar.name.compare(space) != 0) {
					variables.push_back(tempVar);
				}

				pos = str.find(comma);
			}

			// Get the last Variable.
			if (getComment != string::npos) {
				pos = str.find("//");
				tempName = str.substr(0, pos);
				str.erase(0, pos + 2);

				pos = str.find(space);
				tempName.erase(1, pos);
			}
			else {
				pos = str.find(space);
				tempName = str.substr(0, pos);
				str.erase(0, pos + space.length());
			}

			// Some End with spaces, some don't so check.
			if (tempName.compare(space) != 0) {
				tempVar.type = 3;
				tempVar.width = width;
				tempVar.line = count;
				tempVar.sign = false;
				tempVar.name = tempName;

				variables.push_back(tempVar);
			}

		}
		// Look for for-loop.
		else if (firstObj.compare("for") == 0 && secondObj.compare("(") == 0 ) {
			// Define start of statement.
			tempState.start = count;

			// Define conditions.
			pos = str.find("{");
			tempState.condition = str.substr(0, pos - 2);

			// Split condition into the requisite parts.
			// Itteration section.
			pos = tempState.condition.find(";");
			tempState.itVar = tempState.condition.substr(0, pos - 1);
			tempState.condition.erase(0, pos);
			// Condition section.
			pos = tempState.condition.find(";");
			tempState.forCond = tempState.condition.substr(0, pos - 1);
			tempState.condition.erase(0, pos);
			// Incremental section.
			tempState.incState = tempState.condition;

			// Set statement to open.
			tempState.closed = false;
			tempState.type = true;

			// Push statement to statements vector.
			statements.push_back(tempState);

			// Setup internal logic for correct organizing of if-statements.
			numOpenState = statements.size();
			lowestState = numOpenState - 1;
		}
		// Loop for if-statement.
		else if (firstObj.compare("if") == 0 && secondObj.compare("(") == 0) {
			// Define start of statement.
			tempState.start = count;
			tempState.link = -2;

			// Define conditions.
			pos = str.find("{");
			tempState.condition = str.substr(0, pos - 2);

			// Set statement to open.
			tempState.closed = false;
			tempState.type = false;
			

			// Push statement to statements vector.
			statements.push_back(tempState);

			// Setup internal logic for correct organizing of if-statements.
			numOpenState = statements.size();
			lowestState = numOpenState - 1;
			
		}
		// Loop for else-statement.
		else if (firstObj.compare("else") == 0) {
			// Define start of statement.
			tempState.start = count;

			/// Set the index for the parent if.
			// Should work because the lowest state doens't replace until the next if-statement is started.
			// Because you cannot start a new else without closing the previous if then this should point to the parent if-statement of this else.
			tempState.link = lowestState; 
			statements.at(lowestState).link = -1;
						
			/// Do all things you do for if-statements because they have all the same functionality minus the name.

			// Set statement to open.
			tempState.closed = false;
			tempState.type = false;

			// Push statement to statements vector.
			statements.push_back(tempState);

			// Setup internal logic for correct organizing of if-statements.
			numOpenState = statements.size();
			lowestState = numOpenState - 1;
		}
		// Find the end bracket of the statement/loop.
		else if (firstObj.compare("}") && (numOpenState > 0)) {
			// Last opened conditional is an if-statement.
			statements.at(lowestState).closed = true;
			statements.at(lowestState).end = count;
			if (lowestState > 0) {
				lowestState--;
			}
			numOpenState--;

			// find which cond is next.
			if (statements.size() > 0) {
				tempState = statements.at(0);
				for (vector<statement>::size_type stInd = 0; stInd != variables.size(); stInd++) {
					if (statements.at(stInd).closed == true && statements.at(stInd).start > tempState.start) {
						tempState = statements.at(stInd);
					}
				}
			}

			// Check which type of conditional is first.
			cond = tempState.type;

			// We don't have {} for anything other than these two conditionals so far.
		}
		// Failed all initial modifications so it must be an operation.
		else if (firstObj.compare(space) != 0) {

			// Find first input.
			pos = str.find(space);
			thirdObj = str.substr(0, pos); // First or only input.
			str.erase(0, pos + space.length());
			
			// Find which Operation.
			pos = str.find(space);
			fourthObj = str.substr(0, pos); // Find Operation.
			str.erase(0, pos + endLine.length());
			
			// Reset tempOp.
			tempOp.output	= "";
			tempOp.in1		= "";
			tempOp.in2		= "";
			tempOp.sel		= "";
			tempOp.width	= "";
			tempOp.type		= 0; 
			tempOp.line		= 0;
			tempOp.sign		= false;
			tempOp.error	= false;
			tempOp.used		= false;

			// Check for addition.
			if (fourthObj.compare("+") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width, signed, and errors.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.width = variables[i].width;
						tempOp.sign = variables[i].sign;
						numVar++;
					}
					else if (tempOp.in1.compare(variables[i].name) == 0) {
						numVar++;
					}
					else if (tempOp.in2.compare(variables[i].name) == 0) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if(numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. ADD: type = 1
				tempOp.type = 1;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check for subtraction.
			else if (fourthObj.compare("-") == 0) {
				// Find the output.
				tempOp.output = firstObj;
				
				// Find the inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0,pos);
				str.erase(0, pos + space.length());
				
				// for finding width, signed, and error.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in1.compare(variables[i].name) == 0) || (tempOp.in2.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. SUB: type = 2
				tempOp.type = 2;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check for multiplier
			else if (fourthObj.compare("*") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());
				
				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in1.compare(variables[i].name) == 0) || (tempOp.in2.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. MUL: type = 3
				tempOp.type = 3;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's a 'less than' comparator.
			else if (fourthObj.compare("<") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the Inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.in1.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in2.compare(variables[i].name) == 0)) {
						if (variables[i].width > tempOp.width) {
							tempOp.width = variables[i].width;
						}
						numVar++;
					}
					else if ((tempOp.output.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. COMP(lt): type = 4
				tempOp.type = 4;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's a greater than comparator.
			else if (fourthObj.compare(">") == 0) {
				// Find the output.
				tempOp.output = firstObj;
				
				// Find the Inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.in1.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in2.compare(variables[i].name) == 0)) {
						if (variables[i].width > tempOp.width) {
							tempOp.width = variables[i].width;
						}
						numVar++;
					}
					else if ((tempOp.output.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. COMP(gt): type = 5
				tempOp.type = 5;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's an equals comparator.
			else if (fourthObj.compare("==") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the Inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.in1.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in2.compare(variables[i].name) == 0)) {
						if (variables[i].width > tempOp.width) {
							tempOp.width = variables[i].width;
						}
						numVar++;
					}
					else if ((tempOp.output.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. COMP(eq): type = 6
				tempOp.type = 6;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's the 2:1 mux
			else if (fourthObj.compare("?") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the selector.
				tempOp.sel = thirdObj;

				// Find the inputs.
				// Input 1:
				pos = str.find(space);
				tempOp.in1 = str.substr(0, pos);
				str.erase(0, pos + space.length() + 2);
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in1.compare(variables[i].name) == 0) || (tempOp.in2.compare(variables[i].name) == 0) || (tempOp.sel.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 4) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. MUX: type = 7
				tempOp.type = 7;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's shift right.
			else if (fourthObj.compare(">>") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.width = variables[i].width;
						tempOp.sign = variables[i].sign;
						numVar++;
					}
					else if ((tempOp.in1.compare(variables[i].name) == 0) || (tempOp.in2.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. SHR: type = 8
				tempOp.type = 8;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check if it's shift left
			else if (fourthObj.compare("<<") == 0) {
				// Find the output.
				tempOp.output = firstObj;

				// Find the inputs.
				// Input 1:
				tempOp.in1 = thirdObj;
				// Input 2:
				pos = str.find(space);
				tempOp.in2 = str.substr(0, pos);
				str.erase(0, pos + space.length());

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					else if ((tempOp.in1.compare(variables[i].name) == 0) || (tempOp.in2.compare(variables[i].name) == 0)) {
						numVar++;
					}
				}

				// Output error if there are an incorrect number of variables.
				if (numVar != 3) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. SHL: type = 9
				tempOp.type = 9;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			else if (thirdObj.compare(fourthObj) != 0) { // Searched through all known operations (side from reg which is next) so we compare the operation and first input, if they are equal than it is reg or blank so move on.
				// Find if Error
				cout << "Error at line " << count << ", operation '" << fourthObj << "' doesn't exist.\n";
				tempOp.error = true;
				tempOp.line = count; 
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			// Check for register operation or error.
			// (Done here because it would be easier to find, which is unfortunate because it's the most often called operation and it would save some time having it at the top).
			else if (!(firstObj.empty())) { // && getComment == string::npos) {
				
				// Find the output.
				tempOp.output = firstObj;

				// Find the input.
				tempOp.in1 = thirdObj;

				// for finding width and signed.
				for (vector<var>::size_type i = 0; i != variables.size(); i++) {
					if (tempOp.output.compare(variables[i].name) == 0) {
						tempOp.sign = variables[i].sign;
						tempOp.width = variables[i].width;
						numVar++;
					}
					if (tempOp.in1.compare(variables[i].name) == 0) {
						numVar++;
					}
				}

				if (numVar != 2) {
					cout << "Operation error at line " << count << ".\n\tUsed undefined variable in operation.\n";
					tempOp.error = true;
				}

				// We already found the operation. REG: type = 0
				tempOp.type = 0;
				// Reset numVar to track errors.
				numVar = 0;

				// The line it appears on.
				tempOp.line = count;

				// Push the tempOp variable to operations vector.
				tempOp.used = true;

				// If there is an if-statement/for-loop then put op in statements, else put in operations.
				if (numOpenState > 0) {
					statements.at(lowestState).ops.push_back(tempOp);
				}
				else {
					operations.push_back(tempOp);
				}
			}
			
		}
		// Otherwise should be a comment so we ignore it.
		
		// count the line.
		count++;
	}

	// Close the File.
	netList.close();

	// Check if the input file contains information. (only check if there are variables because you could have a program which compiles without operations)
	if (variables.size() != 0) {
		// Start the writeFile function (input file passed in to name the module in the output file).
		writeFile(out, latency, variables, operations, statements, count);
	}
	else {
		// Skip write because the input file contains no information.
	}

	return;
}

void writeFile(char* out, char* latency, vector <var> &variables, vector <operation> &operations, vector <statement> &statements, int endline) {

	fstream vFile;
	vFile.open(out);

	// Variables.
	// Num of each operation, for numbering the function calls in verilog.
	// Unsigned:
	int numReg = 1;
	int numAdd = 1;
	int numSub = 1;
	int numMul = 1;
	int numComp = 1;
	int numMux = 1;
	int numShr = 1;
	int numShl = 1;
	// Signed:
	int numSReg = 1;
	int numSAdd = 1;
	int numSSub = 1;
	int numSMul = 1;
	int numSComp = 1;
	int numSMux = 1;
	int numSShr = 1;
	int numSShl = 1;

	// Differentiate statements from operations to organize nodes.
	vector <node> nodes;		// The vector containing all of the nodes.
	node tempNode;				// Temporary node for setting up ALAP
	vector <int> ready;			// The indicies of the readied nodes.
	vector <int> scheduled;		// The indicies of the readied nodes.
	int line = 0;				// Line for while loop.
	operation blankOp;			// For initializing tempNode.
	vector <int> ifInd;			// For saving the position of the last if-statement.

	// initialize blankOp.
	blankOp.output	= "";
	blankOp.in1		= "";
	blankOp.in2		= "";
	blankOp.sel		= "";
	blankOp.width	= "";
	blankOp.type	= 0;
	blankOp.line	= 0;
	blankOp.sign	= false;
	blankOp.error	= false;
	blankOp.used	= false;

	// Set up ALAP.
	int latency;
	int numAlu = 1;
	int numMul = 1;

	// for inputs.
	string tempWidth;
	bool tempSign;

	// Define input, output, and wire vectors.
	var tempVar;
	vector<var> inputs;
	vector<var> outputs;
	vector<var> wires;
	vector<var> registers;

	/* For State machine set up.

	int opSize = operations.size();

	int stateSize = opSize;
	int bitSize = 0;

	if (stateSize <= 2) {
		bitset <1> numS = 0;
		bitSize = 1;
	}
	else if (stateSize <= 4) {
		bitset <2> numS = 0;
		bitSize = 2;
	}
	else if (stateSize <= 8) {
		bitset <3> numS = 0;
		bitSize = 3;
	}
	else if (stateSize <= 16) {
		bitset <4> numS = 0;
		bitSize = 4;
	}
	else if (stateSize <= 32) {
		bitset <5> numS = 0;
		bitSize = 5;
	}
	else if (stateSize <= 64) { // Probably too far here but might aswell make it robust right?
		bitset <6> numS = 0;
		bitSize = 6;
	}
	
	for (int numState = 0; numState < operations.size(); numState++) {
		vFile << "‘define S" << numState << "\t" << bitSize << "b" << ; // Still need to fix this, make it a binary number that increments every itteration and has the same size as bitSize....
	}
	*/

	// Fill vectors.
	for (vector<var>::size_type i = 0; i != variables.size(); i++) {
		if (variables[i].type == 0) {		// Inputs.
			tempVar = variables[i];
			inputs.push_back(tempVar);
		}
		else if (variables[i].type == 1) {	// Outputs.
			tempVar = variables[i];
			outputs.push_back(tempVar);
		}
		else if (variables[i].type == 2) {	// Wires.
			tempVar = variables[i];
			wires.push_back(tempVar);
		}
		else if (variables[i].type == 3) {	// Registers.
			tempVar = variables[i];
			registers.push_back(tempVar);
		}
	}

	// Setup Nodes (ASAP).
	while (line < endline) {
		// Set operations outside of if-else/for-loops as individual nodes.
		for (vector<operation>::size_type i = 0; i != operations.size(); i++) {
			if (operations.at(i).line == line) {
				tempNode.condition = "";
				tempNode.forCond = "";
				tempNode.incState = "";
				tempNode.itVar = "";
				tempNode.type = 0;
				tempNode.op = operations.at(i);
				nodes.push_back(tempNode);
			}
		}

		// Set if-else statements as nodes.
		for (vector<statement>::size_type j = 0; j != statements.size(); j++) {
			if (statements.at(j).start == line) {
				tempNode.statementType = statements.at(j).type;
				
				if (statements.at(j).type == false) {
					tempNode.op = blankOp;
					tempNode.condition = statements.at(j).condition;
					tempNode.start = statements.at(j).start;
					tempNode.end = statements.at(j).end;
					if (statements.at(j).link < 0) {			// Check the link for the statment to find what type of statement it is ( > -1 is else, -1 is if-statment with an else, -2 is lone if-statemnt.
						if (statements.at(j).link < -1) {
							tempNode.link = -2;					// set to -2 if it's a lone if-statement.
						}
						else {
							tempNode.link = -1;					// otherwise -1 because it has an else.
							ifInd.push_back(nodes.size() + 1);	// Save the index aswell for linking with the 
						}
						tempNode.type = 1;
					}
					else {
						tempNode.link = ifInd.back();
						ifInd.pop_back();
						tempNode.type = 2;
					}
					nodes.push_back(tempNode);
				}
				else {
					tempNode.op = blankOp;
					tempNode.itVar = statements.at(j).itVar;
					tempNode.incState = statements.at(j).incState;
					tempNode.forCond = statements.at(j).forCond;
					tempNode.type = 3;
					nodes.push_back(tempNode);
				}
			}
			else if (statements.at(j).ops.size() > 0) {
				for (vector<operation>::size_type k = 0; k != statements.at(j).ops.size(); k++) {
					if (statements.at(j).ops.at(k).line == line) {
						tempNode.op = statements.at(j).ops.at(k);
						tempNode.type = 0;
						nodes.at(nodes.size() - 1).innerNodes.push_back(tempNode); // places tempNode in the node vector in the previous statement.
					}
				}
			}
		}

		line++;
	}

	// So far we have all operations outside of if-else and we have nested if-else, just need operations nested in each if-else.

	// Write module with name of input file.
	vFile << "module HLSM" << "(Clk, Rst, Start, Done);\n";
	vFile << "\t\tinput Clk, Rst, Start;\n";
	vFile << "\t\toutput reg Done;";
	vFile << "\t\treg State";
	// Define Variables. 

	/// Write input/output variables, then write wires.
	//Inputs
	// Make sure there are Input variables.
	if (inputs.size() != 0) {
		// Setup the first input.
		tempWidth = inputs[0].width;
		tempSign = inputs[0].sign;
		if (inputs[0].sign == false) {
			if (tempWidth.compare("1") != 0) {
				vFile << "\t\tinput [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\t\tinput ";
			}
		}
		else {
			if (tempWidth.compare("1") != 0) {
				vFile << "\t\tinput signed [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\t\tinput signed ";
			}
		}

		for (vector<var>::size_type z = 0; z != inputs.size(); z++) {
			if (inputs[z].width == tempWidth && inputs[z].sign == tempSign) {
				vFile << inputs[z].name;
			}
			else {
				tempWidth = inputs[z].width;
				tempSign = inputs[z].sign;
				if (inputs[z].sign == false) {
					if (tempWidth.compare("1") != 0) {
						vFile << "\n\t\tinput [" << tempWidth << " - 1 : 0] " << inputs[z].name;
					}
					else {
						vFile << "\n\t\tinput " << inputs[z].name;
					}
				}
				else {
					if (tempWidth.compare("1") != 0) {
						vFile << "\n\t\tinput signed [" << tempWidth << " - 1 : 0] " << inputs[z].name;
					}
					else {
						vFile << "\n\t\tinput signed " << inputs[z].name;
					}
				}
			}

			if (z != inputs.size() - 1) {
				vFile << ", ";
			}
			else {
				vFile << ",\n";
			}
		}
	}

	// Outputs
	// Make sure there are output variables.
	if (outputs.size() != 0) {
		// Setup the first output.
		tempWidth = outputs[0].width;
		tempSign = outputs[0].sign;
		if (outputs[0].sign == false) {
			if (tempWidth.compare("1") != 0) {
				vFile << "\t\toutput reg [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\t\toutput reg ";
			}
		}
		else {
			if (tempWidth.compare("1") != 0) {
				vFile << "\t\toutput reg signed [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\t\toutput reg signed ";
			}
		}
		for (vector<var>::size_type j = 0; j != outputs.size(); j++) {
			if (outputs[j].width == tempWidth && outputs[j].sign == tempSign) {
				vFile << outputs[j].name;
			}
			else {
				tempWidth = outputs[j].width;
				tempSign = outputs[j].sign;
				if (outputs[j].sign == false) {
					if (tempWidth.compare("1") != 0) {
						vFile << "\n\t\toutput reg [" << tempWidth << " - 1 : 0] " << outputs[j].name;
					}
					else {
						vFile << "\n\t\toutput reg " << outputs[j].name;
					}
				}
				else {
					if (tempWidth.compare("1") != 0) {
						vFile << "\n\t\toutput reg signed [" << tempWidth << " - 1 : 0] " << outputs[j].name;
					}
					else {
						vFile << "\n\t\toutput reg signed " << outputs[j].name;
					}
				}
			}

			if (j != outputs.size() - 1) {
				vFile << ", ";
			}
			else {
				vFile << ";\n\n"; // two endlines to separate the module variables from the local variables.
			}
		}
	}

	// Wires
	// Make sure there are wire variables.
	if (wires.size() != 0) {
		vector<var>::size_type p = 0;
		// Write wires.
		tempWidth = wires[0].width;
		tempSign = wires[0].sign;

		if (wires[0].sign == false) {
			if (tempWidth.compare("1") != 0) {
				vFile << "\twire [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\twire ";
			}
		}
		else {
			if (tempWidth.compare("1") != 0) {
				vFile << "\twire signed [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\twire signed ";
			}
		}
		
		// Itterate Through the wire vector
		for (vector<var>::size_type k = 0; k != wires.size(); k++) {
			if (wires[k].width.compare(tempWidth) == 0 && wires[k].sign == tempSign) {
				if (k != wires.size() - 1) {
					if ((wires[k + 1].width).compare(tempWidth) != 0) {
						vFile << wires[k].name << ";\n";
					}
					else {
						vFile << wires[k].name << ", ";
					}
				}
				else {
					vFile << wires[k].name << ";\n";
				}
			}
			else {
				tempWidth = wires[k].width;
				tempSign= wires[k].sign;
				if (wires[k].sign == false) {
					if ((wires[k + 1].width).compare(tempWidth) == 0) {
						if (tempWidth.compare("1") != 0) {
							vFile << "\twire [" << tempWidth << " - 1 : 0] " << wires[k].name << ", ";
						}
						else {
							vFile << "\twire " << wires[k].name << ", ";
						}
					}
					else {
						if (tempWidth.compare("1") != 0) {
							vFile << "\twire [" << tempWidth << " - 1 : 0] " << wires[k].name << ";\n";
						}
						else {
							vFile << "\twire " << wires[k].name << ";\n";
						}
					}
				}
				else {
					if ((wires[k + 1].width).compare(tempWidth) == 0) {
						if (tempWidth.compare("1") != 0) {
							vFile << "\twire signed [" << tempWidth << " - 1 : 0] " << wires[k].name << ", ";
						}
						else {
							vFile << "\twire signed " << wires[k].name << ", ";
						}
					}
					else {
						if (tempWidth.compare("1") != 0) {
							vFile << "\twire signed [" << tempWidth << " - 1 : 0] " << wires[k].name << ";\n";
						}
						else {
							vFile << "\twire signed " << wires[k].name << ";\n";
						}
					}
				}
			}
		}
	}

	// Registers
	// make sure there are register variables.
	if (registers.size() != 0) {
		// Registers
		// Setup the first register.
		tempWidth = registers[0].width;
		tempSign = registers[0].sign;
		if (registers[0].sign == false) {
			if (tempWidth.compare("1") != 0) {
				vFile << "\treg [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\treg ";
			}
		}
		else {
			if (tempWidth.compare("1") != 0) {
				vFile << "\treg signed [" << tempWidth << " - 1 : 0] ";
			}
			else {
				vFile << "\treg signed ";
			}
		}
		for (vector<var>::size_type l = 0; l != registers.size(); l++) {
			if (registers[l].width.compare(tempWidth) == 0 && registers[l].sign == tempSign) {
				if (l != registers.size() - 1) {
					if ((registers[l + 1].width).compare(tempWidth) != 0) {
						vFile << registers[l].name << ";\n";
					}
					else {
						vFile << registers[l].name << ", ";
					}
				}
				else {
					vFile << registers[l].name << ";\n";
				}
			}
			else {
				tempWidth = registers[l].width;
				tempSign = registers[l].sign;
				if (registers[l].sign == false) {
					if ((registers[l + 1].width).compare(tempWidth) == 0) {
						if (tempWidth.compare("1") != 0) {
							vFile << "\treg [" << tempWidth << " - 1 : 0] " << registers[l].name << ", ";
						}
						else {
							vFile << "\treg " << registers[l].name << ", ";
						}
					}
					else {
						if (tempWidth.compare("1") != 0) {
							vFile << "\treg [" << tempWidth << " - 1 : 0] " << registers[l].name << ";\n";
						}
						else {
							vFile << "\treg " << registers[l].name << ";\n";
						}
					}
				}
				else {
					if ((registers[l + 1].width).compare(tempWidth) == 0) {
						if (tempWidth.compare("1") != 0) {
							vFile << "\treg signed [" << tempWidth << " - 1 : 0] " << registers[l].name << ", ";
						}
						else {
							vFile << "\treg signed " << registers[l].name << ", ";
						}
					}
					else {
						if (tempWidth.compare("1") != 0) {
							vFile << "\treg signed [" << tempWidth << " - 1 : 0] " << registers[l].name << ";\n";
						}
						else {
							vFile << "\treg signed " << registers[l].name << ";\n";
						}
					}
				}
			}
		}
	}
	// Separate the local variables from the operations.
	vFile << "\n";
	
	// vFile << "always @(posedge clk)\n\tif (reset)\n\t\tstate = ‘S0;\n\telse\n\t\tcase (state)";		// This starts our statemachine dont need yet....
	
	/// Write Operations. Inputs: a, b, d, Clk, Rst | Outputs: q, sum, diff, prod, d, gt, lt, eq
	for (vector<operation>::size_type i = 0; i != operations.size(); i++) {
		if (operations[i].sign == true && operations[i].error == false) {
			// REG(d, Clk, Rst, q)
			if (operations[i].type == 0) {
				vFile << "\tSREG #(" << operations[i].width << ") SREG_" << numSReg << "(" << operations[i].in1 << ", Clk, Rst, " << operations[i].output << ");\n";
				numSReg++;
			}
			// ADD(a, b, sum)
			else if (operations[i].type == 1) {
				vFile << "\tSADD #(" << operations[i].width << ") SADD_" << numSAdd << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSAdd++;
			}
			// SUB(a, b, diff)
			else if (operations[i].type == 2) {
				vFile << "\tSSUB #(" << operations[i].width << ") SSUB_" << numSSub << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSSub++;
			}
			// MUL(a, b, prod)
			else if (operations[i].type == 3) {
				vFile << "\tSMUL #(" << operations[i].width << ") SMUL_" << numSMul << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSMul++;
			}
			// COMP(a, b, gt, lt, eq)
			else if (operations[i].type == 4) { // Less Than
				vFile << "\tSCOMP #(" << operations[i].width << ") SCOMP_" << numSComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", 0, " << operations[i].output << ", 0);\n";
				numSComp++;
			}
			else if (operations[i].type == 5) { // Greater Than
				vFile << "\tSCOMP #(" << operations[i].width << ") SCOMP_" << numSComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ", 0, 0);\n";
				numSComp++;
			}
			else if (operations[i].type == 6) { // Equal To
				vFile << "\tSCOMP #(" << operations[i].width << ") SCOMP_" << numSComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", 0, 0, " << operations[i].output << ");\n";
				numSComp++;
			}
			// MUX(a, b, sel, d)
			else if (operations[i].type == 7) {
				vFile << "\tSMUX #(" << operations[i].width << ") SMUX_" << numSMux << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].sel << ", " << operations[i].output << ");\n";
				numSMux++;
			}
			// SHR(a, sh_amt, d)
			else if (operations[i].type == 8) {
				vFile << "\tSSHR #(" << operations[i].width << ") SSHR_" << numSShr << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSShr++;
			}
			// SHL(a, sh_amt, d)
			else if (operations[i].type == 9) {
				vFile << "\tSSHL #(" << operations[i].width << ") SSHL_" << numSShl << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSShl++;
			}
		}
		else if (operations[i].error == false) {
			// REG(d, Clk, Rst, q)
			if (operations[i].type == 0) {
				vFile << "\tREG #(" << operations[i].width << ") REG_" << numReg << "(" << operations[i].in1 << ", Clk, Rst, " << operations[i].output << ");\n";
				numReg++;
			}
			// ADD(a, b, sum)
			else if (operations[i].type == 1) {
				vFile << "\tADD #(" << operations[i].width << ") ADD_" << numAdd << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numAdd++;
			}
			// SUB(a, b, diff)
			else if (operations[i].type == 2) {
				vFile << "\tSUB #(" << operations[i].width << ") SUB_" << numSub << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numSub++;
			}
			// MUL(a, b, prod)
			else if (operations[i].type == 3) {
				vFile << "\tMUL #(" << operations[i].width << ") MUL_" << numMul << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numMul++;
			}
			// COMP(a, b, gt, lt, eq)
			else if (operations[i].type == 4) { // Less Than
				vFile << "\tCOMP #(" << operations[i].width << ") COMP_" << numComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", 0, " << operations[i].output << ", 0);\n";
				numComp++;
			}
			else if (operations[i].type == 5) { // Greater Than
				vFile << "\tCOMP #(" << operations[i].width << ") COMP_" << numComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ", 0, 0);\n";
				numComp++;
			}
			else if (operations[i].type == 6) { // Equal To
				vFile << "\tCOMP #(" << operations[i].width << ") COMP_" << numComp << "(" << operations[i].in1 << ", " << operations[i].in2 << ", 0, 0, " << operations[i].output << ");\n";
				numComp++;
			}
			// MUX(a, b, sel, d)
			else if (operations[i].type == 7) {
				vFile << "\tMUX #(" << operations[i].width << ") MUX_" << numMux << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].sel << ", " << operations[i].output << ");\n";
				numMux++;
			}
			// SHR(a, sh_amt, d)
			else if (operations[i].type == 8) {
				vFile << "\tSHR #(" << operations[i].width << ") SHR_" << numShr << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numShr++;
			}
			// SHL(a, sh_amt, d)
			else if (operations[i].type == 9) {
				vFile << "\tSHL #(" << operations[i].width << ") SHL_" << numShl << "(" << operations[i].in1 << ", " << operations[i].in2 << ", " << operations[i].output << ");\n";
				numShl++;
			}
		}
	}

	// End the case statement.
	vFile << "endcase";

	// End the loop.
	vFile << "end";

	// End the initialize and module.
	vFile << "\nendmodule\n";

	// Close the File.
	vFile.close();

	return;
}

int main(int argc, char *argv[])
{
	
	// Open files
	if (argc == 3) {
		cout << "Error: need two files, should look like 'hlsyn cFile latency verilogFile'";

		return 1;
	}
	else if (argc == 4) {
		readFile(argv[1], argv[2], argv[3]);

		return 1;
	}
	else
	{
		cout << "Error: Must supply a file\n";
		return 1;
	}
	
}
